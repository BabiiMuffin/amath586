# amath586s2019
Applied Math 586, Spring Quarter 2019

[Class webpage](http://staff.washington.edu/rjl/classes/am586s2019/)

If you want to view Jupyter notebooks, go to the `notebooks` directory and open any notebook, or start at [Index.ipynb](notebooks/Index.ipynb).

For more information, see the 
[Code and notebooks](http://staff.washington.edu/rjl/classes/am586s2019/codes.html)
webpage.

To run them on the cloud, try binder:

[![Binder](http://mybinder.org/badge.svg)](http://mybinder.org/repo/rjleveque/amath586s2019)
