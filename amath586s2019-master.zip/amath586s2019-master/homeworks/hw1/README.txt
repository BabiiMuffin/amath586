
The latex source file hw1.tex inputs some macros from ../latex/macros.tex, 
so if you move hw1.tex elsewhere you might have to move that file as well, or
modify the path.
